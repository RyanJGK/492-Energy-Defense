#!/bin/bash
# Quick start script for deployment

echo "╔════════════════════════════════════════════════════════╗"
echo "║  492-Energy-Defense Quick Start                       ║"
echo "╚════════════════════════════════════════════════════════╝"
echo ""

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "Docker not found. Installing..."
    ./install-docker.sh
    echo ""
    echo "Docker installed. Please logout and login again, then run this script again."
    exit 0
fi

# Check if docker-compose is available
if ! command -v docker-compose &> /dev/null; then
    echo "Error: docker-compose not found"
    echo "Run: ./install-docker.sh"
    exit 1
fi

echo "Starting services..."
docker-compose up -d

echo ""
echo "Waiting for Qwen model download..."
echo "(This will take 1-2 minutes on first run)"
echo ""

sleep 5
docker logs -f ollama-init &
LOGS_PID=$!

# Wait for model to be ready (max 5 minutes)
for i in {1..150}; do
    if docker logs ollama-init 2>&1 | grep -q "Qwen model ready"; then
        kill $LOGS_PID 2>/dev/null
        break
    fi
    sleep 2
done

echo ""
echo "Checking service status..."
docker-compose ps

echo ""
echo "╔════════════════════════════════════════════════════════╗"
echo "║  System Started Successfully!                         ║"
echo "╚════════════════════════════════════════════════════════╝"
echo ""
echo "📊 Access Points:"
echo "   Dashboard:  http://$(hostname -I | awk '{print $1}'):3000"
echo "   Agent API:  http://$(hostname -I | awk '{print $1}'):8000"
echo ""
echo "📝 Next Steps:"
echo "   1. Configure firewall: ufw allow 3000/tcp && ufw allow 8000/tcp"
echo "   2. Test the system: ./test-llm-mode.sh"
echo "   3. View logs: docker-compose logs -f"
echo ""
echo "📚 Documentation: cat DEPLOY_INSTRUCTIONS.txt"
echo ""
