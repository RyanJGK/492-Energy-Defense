#!/bin/bash
# Server setup script for Hetzner - Run as root

echo "╔════════════════════════════════════════════════════════╗"
echo "║  492-Energy-Defense - Hetzner Server Setup            ║"
echo "╚════════════════════════════════════════════════════════╝"
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
   echo "Please run as root (or with sudo)"
   exit 1
fi

echo "[1/6] Updating system packages..."
apt-get update -qq
apt-get upgrade -y -qq

echo "[2/6] Installing Docker..."
if ! command -v docker &> /dev/null; then
    # Install Docker
    apt-get install -y ca-certificates curl gnupg
    install -m 0755 -d /etc/apt/keyrings
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
    chmod a+r /etc/apt/keyrings/docker.gpg
    
    echo \
      "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
      $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
      tee /etc/apt/sources.list.d/docker.list > /dev/null
    
    apt-get update -qq
    apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
    
    echo "✓ Docker installed"
else
    echo "✓ Docker already installed"
fi

echo "[3/6] Installing Docker Compose..."
if ! command -v docker-compose &> /dev/null; then
    # Install docker-compose standalone
    curl -SL https://github.com/docker/compose/releases/latest/download/docker-compose-linux-x86_64 -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
    ln -sf /usr/local/bin/docker-compose /usr/bin/docker-compose
    echo "✓ Docker Compose installed"
else
    echo "✓ Docker Compose already installed"
fi

echo "[4/6] Starting Docker service..."
systemctl enable docker
systemctl start docker
echo "✓ Docker service started"

echo "[5/6] Installing additional tools..."
apt-get install -y jq curl wget htop net-tools -qq
echo "✓ Tools installed"

echo "[6/6] Configuring firewall (UFW)..."
if command -v ufw &> /dev/null; then
    # Allow SSH first (important!)
    ufw allow 22/tcp
    # Allow application ports
    ufw allow 3000/tcp  # Dashboard
    ufw allow 8000/tcp  # Agent API
    ufw allow 5432/tcp  # PostgreSQL (if external access needed)
    # Enable firewall (will prompt if not already enabled)
    echo "y" | ufw enable
    echo "✓ Firewall configured"
else
    echo "⚠ UFW not installed, skipping firewall setup"
fi

echo ""
echo "════════════════════════════════════════════════════════"
echo "✅ Server setup complete!"
echo "════════════════════════════════════════════════════════"
echo ""
echo "Next steps:"
echo "1. Run: docker-compose up -d"
echo "2. Wait 1-2 minutes for model download"
echo "3. Access dashboard: http://$(curl -s ifconfig.me):3000"
echo "4. Access API: http://$(curl -s ifconfig.me):8000"
echo ""
