# Hetzner Deployment Guide

## Simple 3-Step Deployment

### Step 1: Upload Package to Server

On your **local machine**, upload the package:

```bash
scp cyber-agent-deployment.tar.gz root@YOUR_SERVER_IP:/root/
```

### Step 2: Extract and Setup on Server

SSH into your server:

```bash
ssh root@YOUR_SERVER_IP
```

Then run:

```bash
# Extract package
cd /root
tar -xzf cyber-agent-deployment.tar.gz
cd cyber-agent-deploy

# Run setup script (installs Docker, etc.)
chmod +x setup-server.sh
./setup-server.sh
```

### Step 3: Start the Application

```bash
# Start all services
chmod +x quick-start.sh
./quick-start.sh
```

Wait 1-2 minutes for the Qwen model to download.

## Access Your Application

- **Dashboard**: http://YOUR_SERVER_IP:3000
- **Agent API**: http://YOUR_SERVER_IP:8000
- **API Docs**: http://YOUR_SERVER_IP:8000/docs

## Management Commands

```bash
# View all logs
docker-compose logs -f

# View specific service logs
docker logs -f cyber-agent
docker logs -f cyber-backend
docker logs -f cyber-dashboard

# Check service status
docker-compose ps

# Restart services
docker-compose restart

# Stop everything
docker-compose down

# Stop and remove all data
docker-compose down -v
```

## Troubleshooting

### Check if services are running
```bash
docker-compose ps
```

### Check model is loaded
```bash
docker exec ollama-qwen ollama list
```

### Test agent health
```bash
curl http://localhost:8000/health | jq
```

### View firewall status
```bash
ufw status
```

## Configuration

### Switch to Rule-Based Mode (No LLM)

For 100% accurate scoring without LLM overhead:

```bash
# Edit docker-compose.yml
nano docker-compose.yml

# Change: USE_LLM=true
# To:     USE_LLM=false

# Restart
docker-compose restart agent
```

### Change Model Size

Edit `docker-compose.yml` and change:

```yaml
- OLLAMA_MODEL=qwen2.5:0.5b   # Small (400MB)
# to:
- OLLAMA_MODEL=qwen2.5:1.5b   # Medium (900MB)
# or:
- OLLAMA_MODEL=qwen2.5:3b     # Large (2GB)
```

Then:
```bash
docker exec ollama-qwen ollama pull qwen2.5:1.5b
docker-compose restart agent
```

## Security Notes

**For Production:**

1. Change default passwords in docker-compose.yml
2. Restrict firewall rules (use UFW)
3. Set up HTTPS with nginx reverse proxy
4. Create non-root user for operation
5. Enable automatic security updates

## Server Requirements

- **Minimum**: 2 vCPU, 4GB RAM, 20GB disk
- **Recommended**: 4 vCPU, 8GB RAM, 40GB disk
- **OS**: Ubuntu 22.04 or 24.04 LTS

## Support

- Full documentation: README.md
- Troubleshooting: troubleshoot.sh
- Model fix: apply-fix.sh

---

**Project**: 492-Energy-Defense Cybersecurity Agent
**Version**: 2.1.0
