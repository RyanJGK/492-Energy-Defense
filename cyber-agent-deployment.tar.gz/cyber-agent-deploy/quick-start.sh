#!/bin/bash
# Quick start script - Run after setup-server.sh

echo "╔════════════════════════════════════════════════════════╗"
echo "║  Starting 492-Energy-Defense System                   ║"
echo "╚════════════════════════════════════════════════════════╝"
echo ""

echo "[1/4] Starting services..."
docker-compose up -d

echo ""
echo "[2/4] Waiting for Ollama to initialize..."
sleep 10

echo ""
echo "[3/4] Checking service status..."
docker-compose ps

echo ""
echo "[4/4] Monitoring model download..."
echo "This will take 1-2 minutes for Qwen model..."
echo ""
docker logs -f ollama-init &
LOGS_PID=$!

# Wait up to 3 minutes for model download
timeout=180
elapsed=0
while [ $elapsed -lt $timeout ]; do
    if docker logs ollama-init 2>&1 | grep -q "Qwen model ready"; then
        kill $LOGS_PID 2>/dev/null
        break
    fi
    sleep 5
    elapsed=$((elapsed + 5))
done

echo ""
echo "════════════════════════════════════════════════════════"
echo "✅ System is running!"
echo "════════════════════════════════════════════════════════"
echo ""

# Get server IP
SERVER_IP=$(curl -s ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')

echo "🌐 Access your services:"
echo ""
echo "   Dashboard:  http://${SERVER_IP}:3000"
echo "   Agent API:  http://${SERVER_IP}:8000"
echo "   API Docs:   http://${SERVER_IP}:8000/docs"
echo ""
echo "📊 Useful commands:"
echo "   View logs:        docker-compose logs -f"
echo "   Check status:     docker-compose ps"
echo "   Stop system:      docker-compose down"
echo "   Restart:          docker-compose restart"
echo ""
